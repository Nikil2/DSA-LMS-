package view;

import controller.Controller;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Main {
    private static JFrame loginFrame;
    private static JFrame mainMenuFrame;
    static Menu m=new Menu();


    public static void main(String[] args) {

        SwingUtilities.invokeLater(() -> {
            createLoginFrame();
        });


    }

    static void createLoginFrame() {
        loginFrame = new JFrame(" Library_System  - Login");
        loginFrame.setSize(600, 500);
        loginFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);




        JLabel usernameLabel = new JLabel("USERNAME:");
        usernameLabel.setFont(new Font("Arial", Font.BOLD, 25));
        usernameLabel.setHorizontalAlignment(SwingConstants.CENTER);

        JLabel passwordLabel = new JLabel("PASSWORD:");
        passwordLabel.setFont(new Font("Arial", Font.BOLD, 25));
        passwordLabel.setHorizontalAlignment(SwingConstants.CENTER);



        JTextField usernameField = new JTextField();
        usernameField.setFont(new Font("Arial", Font.PLAIN, 25));
        usernameField.setHorizontalAlignment(SwingConstants.CENTER);

        JPasswordField passwordField = new JPasswordField();
        passwordField.setFont(new Font("Arial", Font.PLAIN, 25));
        passwordField.setHorizontalAlignment(SwingConstants.CENTER);



        JButton loginButton = new JButton("Login");
        loginButton.setFont(new Font("Arial", Font.BOLD, 25));
      loginButton.setVerticalAlignment(SwingConstants.CENTER);
      Controller c=new Controller();
      MenuPanel m=new MenuPanel();

        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = usernameField.getText();
                char[] passwordChars = passwordField.getPassword();
                String password = new String(passwordChars);

                if (authenticateUser(username, password)) {
                    loginFrame.dispose();
//                    createMainMenuFrame();
                    m.homescreen();

                } else {
                    JOptionPane.showMessageDialog(loginFrame, "Login failed. Invalid username or password.");
                }

                // Clear fields after login attempt
                usernameField.setText("");
                passwordField.setText("");
            }
        });

        JPanel panel = new JPanel(new GridLayout(3, 2));
        panel.add(usernameLabel);
        panel.add(usernameField);
        panel.add(passwordLabel);
        panel.add(passwordField);
        panel.add(loginButton);



        loginFrame.add(panel);
        loginFrame.setLocationRelativeTo(null); // Center the window on the screen
        loginFrame.setVisible(true);
    }

    private static boolean authenticateUser(String username, String password) {
        // Hardcoded username and password for simplicity
        return username.equals("admin") && password.equals("password");
    }

    private static void createMainMenuFrame() {
        mainMenuFrame = new JFrame("Library_System - Main Menu");
        mainMenuFrame.setSize(600, 500);
        mainMenuFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Create your main menu components here
        JLabel menuLabel = new JLabel("Welcome to the Main Menu!");
        menuLabel.setHorizontalAlignment(SwingConstants.CENTER);


       // mainMenuFrame.add(panel);
        mainMenuFrame.setLocationRelativeTo(null); // Center the window on the screen
        mainMenuFrame.setVisible(true);
        //m.printMainMenu();
    }
}
