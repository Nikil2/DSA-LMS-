package view;//package view;

import controller.Controller;
import model.Book;
import model.Borrow;
import model.Reader;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

import static view.Main.createLoginFrame;

 class MenuPanel extends JPanel {
     JFrame frame=new JFrame();

    public JTextArea outputTextArea;

    public MenuPanel() {
        this.outputTextArea = new JTextArea();
        initialize();
    }
     private static final Scanner sc = new Scanner(System.in);
     private Controller controller;  // Make controller an instance variable

     // Constructor to initialize the controller
     public MenuPanel(Controller controller) {
         this.controller = controller;
         this.outputTextArea = new JTextArea();
         initialize();

     }
    public void homescreen(){

        frame = new JFrame("Menu Example");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(600, 500);
        Controller c=new Controller();
        MenuPanel menuPanel = new MenuPanel(c);

        frame.getContentPane().setLayout(new BorderLayout());
        frame.getContentPane().add(new JScrollPane(menuPanel.outputTextArea), BorderLayout.CENTER);
        frame.getContentPane().add(menuPanel, BorderLayout.WEST);

        frame.setVisible(true);
    }

    private void initialize() {
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));

        List<SubMenu> menuOptions = List.of(
                new SubMenu("Search Book", this::printBookSearchMenu),
                new SubMenu("List all Books", this::printListAllBooksMenu),
                new SubMenu("Search a Reader", this::printReaderSearchMenu),
                new SubMenu("List all Readers", this::printListAllReadersMenu),
                new SubMenu("List Book borrowed by Reader", this::printListBorrowedReaderMenu),
                new SubMenu("Register a new borrowing", this::printBorrowMenu),
                new SubMenu("Register a return", this::printReturnMenu),
                new SubMenu("Add a Book", this::printAddBookMenu)
        );

        for (SubMenu option : menuOptions) {
            JButton button = new JButton(option.title);
            button.setAlignmentX(Component.CENTER_ALIGNMENT);
            button.addActionListener(e -> {
                outputTextArea.setText("");
                option.action.run();
            });

            // Add an empty border to create space between buttons
            button.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));

            add(button);
        }

    }

    public void printBookSearchMenu() {
        removeAll(); // Clear previous components
        revalidate();
        repaint();

        setLayout(new BorderLayout());

        // Title panel
        JPanel titlePanel = new JPanel();
        titlePanel.setLayout(new BoxLayout(titlePanel, BoxLayout.Y_AXIS));
        titlePanel.add(new JLabel("Search for a Book"));

        // Title search panel
        JPanel titleSearchPanel = new JPanel();
        titleSearchPanel.add(new JLabel("Title:"));
        JTextField titleField = new JTextField(20);
        titleSearchPanel.add(titleField);

        // Author search panel
        JPanel authorSearchPanel = new JPanel();
        authorSearchPanel.add(new JLabel("Author:"));
        JTextField authorField = new JTextField(20);
        authorSearchPanel.add(authorField);

        // Search button
        JButton searchButton = new JButton("Search");
        JButton returnButton = new JButton("Return");
        returnButton.addActionListener(e -> {
            homescreen();
        });
        searchButton.addActionListener(e -> {
            String title = titleField.getText().toUpperCase(); // Convert to uppercase for case-insensitive search
            String author = authorField.getText().toUpperCase(); // Convert to uppercase for case-insensitive search

            if (title.isEmpty() && author.isEmpty()) {
                outputTextArea.setText("Please enter either title or author.");
            } else {
                List<Book> bookSearch = controller.bookSearch(b ->
                        (title.isEmpty() || b.getTitle().equalsIgnoreCase(title)) && // Match title if provided or any title if not provided
                                (author.isEmpty() || b.getAuthor().equalsIgnoreCase(author))); // Match author if provided or any author if not provided

                if (bookSearch.isEmpty()) {
                    outputTextArea.setText("Book not found, please try again.");
                } else {
                    StringBuilder resultText = new StringBuilder();
                    for (Book book : bookSearch) {
                        resultText.append(book).append("\n");
                    }
                    outputTextArea.setText(resultText.toString());
                }
            }
        });

        // Add components to title panel
        titlePanel.add(titleSearchPanel);
        titlePanel.add(authorSearchPanel);
        titlePanel.add(searchButton);
        titlePanel.add(Box.createVerticalStrut(10));
        titlePanel.add(returnButton);

        // Add title panel to the main panel
        add(titlePanel, BorderLayout.NORTH);

        // Add output text area
        JScrollPane scrollPane = new JScrollPane(outputTextArea);
        add(scrollPane, BorderLayout.CENTER);

        revalidate();
        repaint();
    }


    public void printListAllBooksMenu() {

        List<Book> bookSearch = controller.orderBooks(Comparator.comparing(Book::getTitle));
        StringBuilder resultText = new StringBuilder();
        for (Book book : bookSearch) {
            resultText.append(book).append("\n");
        }
        outputTextArea.setText(resultText.toString());
    }




    public void printReaderSearchMenu() {
        removeAll(); // Clear previous components
        revalidate();
        repaint();

        setLayout(new BorderLayout());

        // Title panel
        JPanel titlePanel = new JPanel();
        titlePanel.setLayout(new BoxLayout(titlePanel, BoxLayout.Y_AXIS));
        titlePanel.add(new JLabel("Search for a Reader"));

        // Name search panel
        JPanel nameSearchPanel = new JPanel();
        nameSearchPanel.add(new JLabel("Name:"));
        JTextField nameField = new JTextField(20);
        nameSearchPanel.add(nameField);

        // ID search panel
        JPanel idSearchPanel = new JPanel();
        idSearchPanel.add(new JLabel("ID:"));
        JTextField idField = new JTextField(20);
        idSearchPanel.add(idField);

        // Search button
        JButton searchButton = new JButton("Search");
        JButton returnButton = new JButton("Return");
        returnButton.addActionListener(e -> {
            homescreen();
        });

        // Output text area
        JTextArea outputTextArea = new JTextArea(10, 20);
        outputTextArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(outputTextArea);

        searchButton.addActionListener(e -> {
            String name = nameField.getText();
            String id = idField.getText();

            if (name.isEmpty() && id.isEmpty()) {
                outputTextArea.setText("Please enter either name or ID.");
            } else {
                Object searchResult = controller.readerSearch(r -> {
                    boolean matchName = name.isEmpty() || r.getName().equals(name);
                    boolean matchId = id.isEmpty() || r.getId().equals(id);
                    return matchName && matchId;
                });

                if (searchResult instanceof Reader) {
                    outputTextArea.setText(((Reader) searchResult).toString());
                } else if (searchResult instanceof List<?>) {
                    List<Reader> searchResults = (List<Reader>) searchResult;
                    if (searchResults.isEmpty()) {
                        outputTextArea.setText("Reader not found, please try again.");
                    } else {
                        StringBuilder resultText = new StringBuilder();
                        for (Reader reader : searchResults) {
                            resultText.append(reader).append("\n");
                        }
                        outputTextArea.setText(resultText.toString());
                    }
                } else {
                    outputTextArea.setText("Error occurred while searching for reader.");
                }
            }
        });

        // Add components to title panel
        titlePanel.add(nameSearchPanel);
        titlePanel.add(idSearchPanel);
        titlePanel.add(searchButton);
        titlePanel.add(Box.createVerticalStrut(10));
        titlePanel.add(returnButton);

        // Add title panel to the main panel
        add(titlePanel, BorderLayout.NORTH);

        // Add output text area within a scroll pane
        add(scrollPane, BorderLayout.CENTER);

        revalidate();
        repaint();
    }


    private void printListAllReadersMenu() {
        List<Reader> sortedReaders = controller.orderReaders(Comparator.comparing(Reader::getName));
        StringBuilder resultText = new StringBuilder();
        for (Reader reader : sortedReaders) {
            resultText.append(reader).append("\n");
        }
        outputTextArea.setText(resultText.toString());
    }

    public void printListBorrowedReaderMenu() {
        removeAll(); // Clear previous components
        revalidate();
        repaint();

        setLayout(new BorderLayout());

        // Title panel
        JPanel titlePanel = new JPanel();
        titlePanel.setLayout(new BoxLayout(titlePanel, BoxLayout.Y_AXIS));
        titlePanel.add(new JLabel("Search for a Reader"));

        // Name search panel
        JPanel nameSearchPanel = new JPanel();
        nameSearchPanel.add(new JLabel("Name:"));
        JTextField nameField = new JTextField(20);
        nameSearchPanel.add(nameField);

        // ID search panel
        JPanel idSearchPanel = new JPanel();
        idSearchPanel.add(new JLabel("ID:"));
        JTextField idField = new JTextField(20);
        idSearchPanel.add(idField);

        // Search button
        JButton searchButton = new JButton("Search");
        JButton returnButton = new JButton("Return");
        returnButton.addActionListener(e -> {
            homescreen();
        });

        // Output text area
        JTextArea outputTextArea = new JTextArea(10, 20);
        outputTextArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(outputTextArea);

        searchButton.addActionListener(e -> {
            String name = nameField.getText();
            String id = idField.getText();

            if (name.isEmpty() && id.isEmpty()) {
                outputTextArea.setText("Please enter either name or ID.");
            } else {
                Object searchResult = controller.readerSearch(r -> {
                    boolean matchName = name.isEmpty() || r.getName().equals(name);
                    boolean matchId = id.isEmpty() || r.getId().equals(id);
                    return matchName && matchId;
                });

                if (searchResult instanceof Reader) {
                    Reader reader = (Reader) searchResult;
                    boolean borrowFound = false;
                    List<Borrow> currentBorrows = controller.orderBorrowings(Comparator.comparing(Borrow::getBorrowDate));
                    for (Borrow borrow : currentBorrows) {
                        if (borrow.getReaderId().equals(reader.getId()) && !borrow.isBorrowReturned() && !borrow.isInQueue()) {
                            Book book = controller.findBook(borrow.getBookId());
                            if (!borrowFound) {
                                outputTextArea.append("Currently borrowed book(s) for " + reader.getName() + ":\n");
                            }
                            outputTextArea.append(book.toString() + "\n");
                            borrowFound = true;
                        }
                    }
                    if (!borrowFound) {
                        outputTextArea.append("The reader has currently no book borrowed\n");
                    }
                } else {
                    outputTextArea.setText("The reader was not found in database.");
                }
            }
        });

        // Add components to title panel
        titlePanel.add(nameSearchPanel);
        titlePanel.add(idSearchPanel);
        titlePanel.add(searchButton);
        titlePanel.add(Box.createVerticalStrut(10));
        titlePanel.add(returnButton);

        // Add title panel to the main panel
        add(titlePanel, BorderLayout.NORTH);

        // Add output text area within a scroll pane
        add(scrollPane, BorderLayout.CENTER);

        revalidate();
        repaint();
    }




    public void printBorrowMenu() {
        removeAll(); // Clear previous components
        revalidate();
        repaint();

        setLayout(new BorderLayout());

        // Title panel
        JPanel titlePanel = new JPanel();
        titlePanel.setLayout(new BoxLayout(titlePanel, BoxLayout.Y_AXIS));
        titlePanel.add(new JLabel("Borrow a Book"));

        // Book ID panel
        JPanel bookIdPanel = new JPanel();
        bookIdPanel.add(new JLabel("Book ID:"));
        JTextField bookIdField = new JTextField(20);
        bookIdPanel.add(bookIdField);

        // Reader ID panel
        JPanel readerIdPanel = new JPanel();
        readerIdPanel.add(new JLabel("Reader ID:"));
        JTextField readerIdField = new JTextField(20);
        readerIdPanel.add(readerIdField);

        // Borrow button
        JButton borrowButton = new JButton("Borrow");
        JButton returnButton = new JButton("Return");
        returnButton.addActionListener(e -> {
            homescreen();
        });

        // Output text area
        JTextArea outputTextArea = new JTextArea(10, 20);
        outputTextArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(outputTextArea);

        borrowButton.addActionListener(e -> {
            String bookID = bookIdField.getText();
            String readerID = readerIdField.getText();

            Book book = controller.findBook(bookID);
            Reader reader = controller.findReader(readerID);

            if (book != null && reader != null) {
                if (controller.isBookNotBorrowed(book)) {
                    controller.borrowBook(reader, book);
                    outputTextArea.setText("Book " + book.getTitle() + " was successfully borrowed to " + reader.getName() + "\n");
                } else {
                    outputTextArea.setText("Book " + book.getTitle() + " is not available at the moment\n");
                    // Additional logic if needed for showing queue menu
                }
            } else {
                if (book == null) {
                    outputTextArea.setText("Book ID " + bookID + " not found\n");
                }
                if (reader == null) {
                    outputTextArea.append("Reader ID " + readerID + " not found\n");
                }
            }
        });

        // Add components to the main panel
        titlePanel.add(bookIdPanel);
        titlePanel.add(readerIdPanel);
        titlePanel.add(borrowButton);
        titlePanel.add(Box.createVerticalStrut(10));
        titlePanel.add(returnButton);

        // Add title panel to the main panel
        add(titlePanel, BorderLayout.NORTH);

        // Add output text area within a scroll pane
        add(scrollPane, BorderLayout.CENTER);

        revalidate();
        repaint();
    }


    public void printReturnMenu() {
        removeAll(); // Clear previous components
        revalidate();
        repaint();

        setLayout(new BorderLayout());

        // Title panel
        JPanel titlePanel = new JPanel();
        titlePanel.setLayout(new BoxLayout(titlePanel, BoxLayout.Y_AXIS));
        titlePanel.add(new JLabel("Return a Book"));

        // Book ID panel
        JPanel bookIdPanel = new JPanel();
        bookIdPanel.add(new JLabel("Book ID:"));
        JTextField bookIdField = new JTextField(20);
        bookIdPanel.add(bookIdField);

        // Return button
        JButton returnButton = new JButton("Return");
        JButton returnButton1 = new JButton("Main Menu");
        returnButton.addActionListener(e -> {
            homescreen();
        });

        // Output text area
        JTextArea outputTextArea = new JTextArea(10, 20);
        outputTextArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(outputTextArea);

        returnButton.addActionListener(e -> {
            String bookID = bookIdField.getText();
            Book book = controller.findBook(bookID);

            if (book != null) {
                if (!controller.isBookNotBorrowed(book)) {
                    Borrow nextBorrow = controller.returnBook(book);
                    outputTextArea.setText("Book " + book.getTitle() + " was\n successfully returned\n");

                    if (nextBorrow != null) {
                        Reader reader = controller.findReader(nextBorrow.getReaderId());
                        outputTextArea.append("Next person in queue:\n" + reader.toString() + "\n");

                        // Additional logic if needed for showing lend menu
                    }
                } else {
                    outputTextArea.setText("Book " + book.getTitle() + " is currently not borrowed\n");
                }
            } else {
                outputTextArea.setText("Book ID " + bookID + " not found\n");
            }
        });

        // Add components to the main panel
        titlePanel.add(bookIdPanel);

        titlePanel.add(returnButton);
        titlePanel.add(Box.createVerticalStrut(10));
        titlePanel.add(returnButton1);

        // Add title panel to the main panel
        add(titlePanel, BorderLayout.NORTH);

        // Add output text area within a scroll pane
        add(scrollPane, BorderLayout.CENTER);

        revalidate();
        repaint();
    }


    public void printAddBookMenu() {
        removeAll(); // Clear previous components
        revalidate();
        repaint();

        setLayout(new BorderLayout());

        // Title panel
        JPanel titlePanel = new JPanel();
        titlePanel.setLayout(new BoxLayout(titlePanel, BoxLayout.Y_AXIS));
        titlePanel.add(new JLabel("Add a New Book"));

        // Book ID panel
        JPanel bookIdPanel = new JPanel();
        bookIdPanel.add(new JLabel("Book ID:"));
        JTextField bookIdField = new JTextField(20);
        bookIdPanel.add(bookIdField);

        // Book Title panel
        JPanel bookTitlePanel = new JPanel();
        bookTitlePanel.add(new JLabel("Book Title:"));
        JTextField bookTitleField = new JTextField(20);
        bookTitlePanel.add(bookTitleField);

        // Author panel
        JPanel authorPanel = new JPanel();
        authorPanel.add(new JLabel("Author:"));
        JTextField authorField = new JTextField(20);
        authorPanel.add(authorField);

        // Year panel
        JPanel yearPanel = new JPanel();
        yearPanel.add(new JLabel("Year:"));
        JTextField yearField = new JTextField(20);
        yearPanel.add(yearField);

        // Gender panel
        JPanel genderPanel = new JPanel();
        genderPanel.add(new JLabel("Gender:"));
        JTextField genderField = new JTextField(20);
        genderPanel.add(genderField);

        // Availability panel
        JPanel availabilityPanel = new JPanel();
        availabilityPanel.add(new JLabel("Available (true/false):"));
        JTextField availabilityField = new JTextField(20);
        availabilityPanel.add(availabilityField);

        // Add button
        JButton addButton = new JButton("Add Book");
        JButton returnButton = new JButton("Return");
        returnButton.addActionListener(e -> {

            homescreen();


        });

        // Output text area
        JTextArea outputTextArea = new JTextArea(10, 20);
        outputTextArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(outputTextArea);

        addButton.addActionListener(e -> {
            String bookID = bookIdField.getText();
            String title = bookTitleField.getText();
            String author = authorField.getText();
            int year = Integer.parseInt(yearField.getText());
            String gender = genderField.getText();
            boolean isAvailable = Boolean.parseBoolean(availabilityField.getText());

            if (!bookID.isEmpty() && !title.isEmpty() && !author.isEmpty()) {
                // Create a new book object
                Book newBook = new Book(bookID, title, author, year, gender, isAvailable);
                // Add the new book to the controller
                controller.addBook(newBook);
                // Display success message
                outputTextArea.setText("New book added successfully:\n" + newBook.toString());
            } else {
                // Display error message if any field is empty
                outputTextArea.setText("Please fill in all fields.");
            }
        });

        // Add components to the main panel
        titlePanel.add(bookIdPanel);
        titlePanel.add(bookTitlePanel);
        titlePanel.add(authorPanel);
        titlePanel.add(yearPanel);
        titlePanel.add(genderPanel);
        titlePanel.add(availabilityPanel);
        titlePanel.add(addButton);
        titlePanel.add(Box.createVerticalStrut(10));
        titlePanel.add(returnButton);

        // Add title panel to the main panel
        add(titlePanel, BorderLayout.NORTH);

        // Add output text area within a scroll pane
        add(scrollPane, BorderLayout.CENTER);

        revalidate();
        repaint();
    }

}

     class SubMenu {
        final String title;
        final Runnable action;

        public SubMenu(String title, Runnable action) {
            this.title = title;
            this.action = action;
        }
    }








